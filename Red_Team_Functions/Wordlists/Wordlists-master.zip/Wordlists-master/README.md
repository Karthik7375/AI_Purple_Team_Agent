# Wordlists
A repository of wordlists for enumeration. 

Contains json files to run with gf to fins common params vulnerable to exploits
wordlists for common bug bounty vunerabilities
other useful wordlists for infosec and bug bounty
